package main

import (
	"encoding/hex"
	"fmt"
)

func findPassword() {
	nonce := make([]byte, 12)
	data := "jwang34@illinoistech.edu"

	ciphermac, _ := hex.DecodeString(
		"d293749e3f1c3cf6babc1a0913caf1c088b3347698ab86b8da3a165dfae2b87dc695da5a8d81cee1d1dade2e01d1b311f9e9ccc4ee59a6d4992df4ec55112c494ba1")

	fmt.Printf("finding password for nonce=%x, data=%s, ciphermac=%x...\n",
		nonce, data, ciphermac)

	for i := 0; i < 10000; i++ {
		password := fmt.Sprintf("%04d", i)

		// Modify code below to check that if sha256(password) is a correct
		// key to decrypt the ciphertext with MAC in ciphermac, which is
		// obtained via AES-GCM with a 0 nouce and the data being jwang34@illinoistech.edu
		//
		// Once found, show the correct password as well as the plaintext.
		if false {
			fmt.Printf("  correct password=%s\n", password)
			break
		}
	}
}

func main() {
	validateSHA256()
	validateAESGCM()
	findPassword()
}
