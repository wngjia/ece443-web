package main

import (
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"time"
)

type certInfo struct {
	Subject        string    `json:"subject"`
	Issuer         string    `json:"issuer"`
	SerialNumber   string    `json:"serialNumber"`
	NotBefore      time.Time `json:"notBefore"`
	NotAfter       time.Time `json:"notAfter"`
	EmailAddresses []string  `json:"emailAddresses,omitempty"`
	Fingerprint    string    `json:"fingerprint"`
}

func echoHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	// If no TLS or no client cert, say so
	if r.TLS == nil || len(r.TLS.PeerCertificates) == 0 {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`{"message":"no client certificate was provided"}`))
		return
	}

	leaf := r.TLS.PeerCertificates[0]

	fp := sha256.Sum256(leaf.Raw)

	info := certInfo{
		Subject:        leaf.Subject.String(),
		Issuer:         leaf.Issuer.String(),
		SerialNumber:   leaf.SerialNumber.Text(16),
		NotBefore:      leaf.NotBefore,
		NotAfter:       leaf.NotAfter,
		EmailAddresses: leaf.EmailAddresses,
		Fingerprint:    fmt.Sprintf("%X", fp),
	}

	enc := json.NewEncoder(w)
	enc.SetIndent("", "  ")
	_ = enc.Encode(info)
}

func loadClientCAPool(path string) *x509.CertPool {
	if path == "" {
		return nil
	}
	b, err := os.ReadFile(path)
	if err != nil {
		log.Fatalf("read client CA file (-client-ca): %v", err)
	}
	p := x509.NewCertPool()
	if !p.AppendCertsFromPEM(b) {
		log.Fatalf("no certificates found in %s", path)
	}
	return p
}

func main() {
	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "Usage: web-server [options]\n")
		fmt.Fprintf(os.Stderr, "Options:\n")
		flag.PrintDefaults()
	}
	addr := flag.String("addr", "127.0.0.1:8080", "listen address")
	certPath := flag.String("cert", "your-server-certificate", "server certificate (PEM)")
	keyPath := flag.String("key", "your-server-private-key", "server private key (PEM)")
	clientCA := flag.String("client-ca", "", "CA to verify client certs (PEM). Empty = don't verify.")
	flag.Parse()

	// Load server cert/key
	serverCert, err := tls.LoadX509KeyPair(*certPath, *keyPath)
	if err != nil {
		log.Fatalf("load server keypair: %v", err)
	}

	// Client CA pool (for verifying client certs)
	clientCAPool := loadClientCAPool(*clientCA)

	clientAuth := tls.NoClientCert
	if clientCAPool != nil {
		clientAuth = tls.VerifyClientCertIfGiven
	}

	tlsCfg := &tls.Config{
		Certificates: []tls.Certificate{serverCert},
		MinVersion:   tls.VersionTLS12,
		ClientAuth:   clientAuth,
		ClientCAs:    clientCAPool,
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/", echoHandler)

	srv := &http.Server{
		Addr:      *addr,
		Handler:   mux,
		TLSConfig: tlsCfg,
	}

	log.Printf("HTTPS listening on https://%s (clientAuth=%v)", *addr, clientAuth)
	log.Fatal(srv.ListenAndServeTLS("", "")) // certs provided via tls.Config
}
