package main

import (
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
)

// loadCertPool returns a cert pool according to -ca option:
//
//	"": empty pool (no trusted roots; verification will fail)
//	<filepath>: pool with only the provided PEM(s)
func loadCertPool(caOpt string) (*x509.CertPool, error) {
	switch caOpt {
	case "":
		return x509.NewCertPool(), nil
	default:
		b, err := os.ReadFile(caOpt)
		if err != nil {
			return nil, fmt.Errorf("read CA file: %w", err)
		}
		p := x509.NewCertPool()
		if !p.AppendCertsFromPEM(b) {
			return nil, fmt.Errorf("no certificates found in %s", caOpt)
		}
		return p, nil
	}
}

func main() {
	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "Usage: web-client [options] <url>\n")
		fmt.Fprintf(os.Stderr, "Options:\n")
		flag.PrintDefaults()
	}
	caOpt := flag.String("ca", "", `CA option: "" (no CAs), or path to PEM`)
	certPath := flag.String("cert", "", "Client certificate PEM (optional)")
	keyPath := flag.String("key", "", "Client private key PEM (optional)")
	flag.Parse()

	// Expect URL as first positional argument
	if flag.NArg() < 1 {
		flag.Usage()
		os.Exit(1)
	}
	url := flag.Arg(0)

	// TLS config
	tlsCfg := &tls.Config{
		MinVersion:         tls.VersionTLS12,
		InsecureSkipVerify: false,
	}

	// RootCAs
	pool, err := loadCertPool(*caOpt)
	if err != nil {
		log.Fatalf("prepare root pool: %v", err)
	}
	tlsCfg.RootCAs = pool

	// Optional client cert
	if *certPath != "" || *keyPath != "" {
		if *certPath == "" || *keyPath == "" {
			log.Fatalf("both -cert and -key must be provided together")
		}
		c, err := tls.LoadX509KeyPair(*certPath, *keyPath)
		if err != nil {
			log.Fatalf("load client keypair: %v", err)
		}
		tlsCfg.Certificates = []tls.Certificate{c}
	}

	client := &http.Client{
		Transport: &http.Transport{TLSClientConfig: tlsCfg},
	}

	resp, err := client.Get(url)
	if err != nil {
		log.Fatalf("request failed: %v", err)
	}
	defer resp.Body.Close()

	// Quick TLS summary
	if resp.TLS != nil {
		fmt.Println("=== TLS Summary ===")
		fmt.Printf("HTTP Protocol: %s\n", resp.Proto)
		fmt.Printf("Cipher Suite: 0x%04x\n", resp.TLS.CipherSuite)
		if len(resp.TLS.PeerCertificates) > 0 {
			fmt.Printf("Server Cert Subject: %s\n", resp.TLS.PeerCertificates[0].Subject)
			fmt.Printf("Server Cert Issuer : %s\n", resp.TLS.PeerCertificates[0].Issuer)
			fp := sha256.Sum256(resp.TLS.PeerCertificates[0].Raw)
			fmt.Printf("Server Cert Fingerprint (SHA-256): %X\n", fp)
		}
		ok := len(resp.TLS.VerifiedChains) > 0
		fmt.Printf("Server verification: %v\n", ok)
		fmt.Println("====================")
	}

	fmt.Printf("HTTP %s\n\n", resp.Status)
	body, _ := io.ReadAll(resp.Body)
	os.Stdout.Write(body)
}
