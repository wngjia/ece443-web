module web-client

go 1.19
