module mycrypto

go 1.19
