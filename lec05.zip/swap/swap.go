// swap/swap.go
package main

import "fmt"

func swap(pa, pb *int) {
	fmt.Printf("addr(a)=%p, addr(b)=%p\n", pa, pb)
	// *pa, *pb = *pb, *pa
	tmp := *pa
	*pa = *pb
	*pb = tmp
}
